package TCPServer;
import java.io.*; 
import java.net.*;

public class TCPServer {
	public static void main(String[]args)throws Exception{
	      String clientSentence; 
	      String outsentence  ;
	      BufferedReader infromserver = new BufferedReader(new InputStreamReader(System.in)); 
	      System.out.println( InetAddress.getLocalHost());
	      ServerSocket welcomeSocket = new ServerSocket(1999);  
    	  Socket connectionSocket = welcomeSocket.accept();
    	  System.out.println("connected");
    	  BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream())); 
	      while(true){
	    	      	  DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
	    	      	  clientSentence = inFromClient.readLine(); 
	    	  System.out.println(clientSentence);
	    	  outsentence = infromserver.readLine()+"\n";
	    	  outToClient.writeBytes(serversentence);
	      }
		
	}

}