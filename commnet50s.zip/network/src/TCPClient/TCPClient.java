package TCPClient;
import java.io.*;
import java.net.*;

public class TCPClient {
	public static void main (String[]args)throws Exception{
		String insentence ;
		String modifiedSentence ;
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		if(inFromUser.readLine().equals("CONNECT")){
		Socket clientSocket =new Socket("172.0.0.14",1999); 
		System.out.println("connected!!");
		while(!inFromUser.readLine().equals("CLOSE")){
			BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			DataOutputStream outToServer= new DataOutputStream(clientSocket.getOutputStream());
			insentence = inFromUser.readLine();
			outToServer.writeBytes(sentence + '\n');
			modifiedSentence =inFromServer.readLine() ;
			System.out.println("FROM SERVER"+": "+ modifiedSentence );}
			clientSocket.close();}
		}

}
